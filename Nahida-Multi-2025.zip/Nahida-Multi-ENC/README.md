╭─❍──────────────❍─╮
 𝗧𝗘𝗥𝗜𝗠𝗔 𝗞𝗔𝗦𝗜𝗛 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗦𝗖𝗥𝗜𝗣𝗧 𝗜𝗡𝗜
╰─❍──────────────❍─╯

╭── ⋆⋅☆⋅⋆ ──╮
│  ✦ 𝗩𝗶𝘁𝗮
│  ✦ 𝗗𝗲𝘄𝗶
│  ✦ 𝗟𝗮𝘆𝗹𝗮𝗮 
│  ✦ 𝗔𝗰𝗵𝗮 
│  ✦ 𝗡𝗼𝘃𝗶 
╰── ⋆⋅☆⋅⋆ ──╯

╭──── ⭑ 𝗦𝗢𝗖𝗜𝗔𝗟 𝗠𝗘𝗗𝗜𝗔 ⭑ ────╮
│ 🌐 *Instagram:* @laylaa_imup
│ ▶️ *YouTube:* @laylaa-yes
│ 💬 *Telegram:* @laylaa_imup ( ON ) 
│ 📘 *Facebook:* fb.com/ ( ga punya ) 
│ 💬 *WhatsApp:* ( KENON ) 
╰────────────────────────────╯

🛠️ 𝗦𝗨𝗣𝗢𝗥𝗧 𝗕𝗢𝗧 & 𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗦𝗨𝗕𝗦𝗖𝗥𝗜𝗕𝗘 ✨
─────────────
╭─❍ 𝗦𝗘𝗧𝗨𝗣 𝗗𝗔𝗦𝗔𝗥
│ ✦ Update sistem Termux:
│ ↳ pkg update && pkg upgrade -y
│ ✦ Izinkan akses file:
│ ↳ termux-setup-storage
│ ✦ Install module penting:
│ ↳ pkg install git nodejs ffmpeg imagemagick yarn -y
╰───────────────❍
╭─❍ 𝗣𝗔𝗦𝗔𝗡𝗚 𝗦𝗖𝗥𝗜𝗣𝗧 𝗕𝗢𝗧
│ ✦ Clone dari GitHub:
│ ↳ git clone https://github.com/laylaa-team/Laylaa-MD
│ ✦ Masuk folder bot:
│ ↳ cd Laylaa-MD
│ ✦ Kalau file ZIP:
│ ↳ pkg install unzip -y
│ ↳ unzip namafile.zip && cd nama-folder
╰───────────────❍
╭─❍ 𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗗𝗘𝗣𝗘𝗡𝗗𝗘𝗡𝗖𝗬
│ ✦ Jalankan perintah:
│ ↳ yarn install
│ ✦ Atau jika error:
│ ↳ npm install
╰───────────────❍
╭─❍ 𝗝𝗔𝗟𝗔𝗡𝗞𝗔𝗡 𝗕𝗢𝗧
│ ✦ Untuk mulai bot:
│ ↳ node .
│ ✦ Atau jika ada start.sh:
│ ↳ bash start.sh
│ ✦ Scan QR code yang muncul.
╰───────────────❍
╭─❍ 𝗕𝗜𝗔𝗥 𝗕𝗢𝗧 𝗧𝗜𝗗𝗔𝗞 𝗠𝗔𝗧𝗜
│ ✦ Install PM2:
│ ↳ npm install -g pm2
│ ✦ Jalankan via PM2:
│ ↳ pm2 start node -- .
│ ✦ Simpan konfigurasi:
│ ↳ pm2 save
│ ✦ Auto start saat boot:
│ ↳ pm2 startup
╰───────────────❍
╭─❍ 𝗥𝗘𝗞𝗢𝗠𝗘𝗡𝗗𝗔𝗦𝗜
│ ✦ Bot ringan & aman: Laylaa MD, 
│ ✦ Cocok untuk pemula & enc
│ ✦ beli no enc ya harga 35k kasih free panel unlimited!! 
╰───────────────❍
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys')
const fs = require('fs')
const path = require('path')

// fungsi auto load plugin
function loadPlugins() {
  const plugins = {}
  const pluginDir = path.join(__dirname, 'plugins')
  fs.readdirSync(pluginDir).forEach(file => {
    if (file.endsWith('.js')) {
      const plugin = require(path.join(pluginDir, file))
      plugins[file.replace('.js', '')] = plugin
    }
  })
  return plugins
}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('./session')
  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
    browser: ["RynxxGroupBot", "Chrome", "1.0.0"]
  })

  sock.ev.on('creds.update', saveCreds)

  // reload plugin setiap perubahan file
  let plugins = loadPlugins()
  fs.watch(path.join(__dirname, 'plugins'), () => {
    Object.keys(require.cache).forEach(key => {
      if (key.includes('/plugins/')) delete require.cache[key]
    })
    plugins = loadPlugins()
    console.log('[ PLUGINS RELOADED ]')
  })

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut
      console.log('connection closed due to ', lastDisconnect.error, ', reconnecting ', shouldReconnect)
      if (shouldReconnect) startBot()
    } else if (connection === 'open') {
      console.log('�7�3 Bot Rynxx Group Connected!')
    }
  })

  sock.ev.on('messages.upsert', async (m) => {
    const msg = m.messages[0]
    if (!msg.message) return
    if (msg.key.remoteJid === 'status@broadcast') return

    const from = msg.key.remoteJid
    if (!from.endsWith('@g.us')) return // hanya grup

    const type = Object.keys(msg.message)[0]
    const body =
      (type === 'conversation' && msg.message.conversation) ||
      (type === 'extendedTextMessage' && msg.message.extendedTextMessage.text) ||
      ''
    if (!body) return

    const prefix = '.'
    if (!body.startsWith(prefix)) return
    const [command, ...args] = body.slice(1).trim().split(/ +/)

    const metadata = await sock.groupMetadata(from)
    const isAdmin = metadata.participants.some(p => (p.id === msg.key.participant && (p.admin === 'admin' || p.admin === 'superadmin')))
    const sender = msg.key.participant

    if (plugins[command]) {
      try {
        await plugins[command](sock, msg, from, args, metadata, isAdmin, sender)
      } catch (e) {
        console.log('Error di plugin', command, e)
        sock.sendMessage(from, { text: `�7�4 Error di command: ${command}` }, { quoted: msg })
      }
    }
  })
}

startBot()